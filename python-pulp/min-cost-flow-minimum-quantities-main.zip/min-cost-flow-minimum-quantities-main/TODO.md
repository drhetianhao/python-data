# Technical TODO

- find alternative to `rand()`?

# Non- Technical TODO

- Operator križanja ukomponirati i provjeriti
- Dovršiti genetski algoritam
- Vidit jel to štima u razumnom vremenu
- Testirati CPLEX vs genetski i vidit jel to smisleno 
- Na temelju (4) odlučit treba li šta ključno optimizirati u genetskom radi poboljšanja ili krenuti u alternativnom smjeru
- Rad na prezentaciji kad nam pisanje koda bude navrh znaš već čega
- Ukomponirati sučelje da možda prikazuje samo rješenje
- Kako formalno napraviti usporedbu algoritama? Kako to prikazati?
- Jel trebamo pisat seminar za ovo lol?
