# Python-PuLP-
#### Simple Linear Programming (Giapetto LP Problem) Using Python PuLP
#### The Reddy Mikks Company Problem 
#### Transportation Problem (PUNJAB FLOUR Mill)
#### Capacitated Facility Location Problem
#### Blending Problem
#### Multi-Period Work Schedule Problem --- Watson Book - Page 109
#### Fixed-Charge IP (Gandhi Cloth Company) - Watson Book Page # 480
#### APP Problem - Fixed Work Force Model

Playlist:
https://www.youtube.com/watch?v=qMA0mdFHnIk&list=PLW39o_Nls7NzCSXteYQjuimi52sIJtd_T
