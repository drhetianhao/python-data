if menu_option == 1:
    single_player()
elif menu_option == 2:
    multi_player()
elif menu_option == 3:
    load_game()
elif menu_option == 4:
    save_game()
elif menu_option == 5:
    reset_high_score()
else:
    print("No such option!");
