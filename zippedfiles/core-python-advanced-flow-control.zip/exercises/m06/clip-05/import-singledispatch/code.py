from functools import singledispatch
