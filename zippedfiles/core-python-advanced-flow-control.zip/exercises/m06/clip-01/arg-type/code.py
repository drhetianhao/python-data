square = Square(2, 6, 7)
circle = Circle(2, 6, 7)

draw(square)
draw(circle)


draw_square(square)
draw_circle(circle)


square.draw()
circle.draw()
