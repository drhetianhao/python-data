d = my_rect.intersects(my_circle)
d = type(my_rect).intersects(my_rect, my_circle)
d = Rectangle.intersects(self=my_rect, shape=my_circle)
