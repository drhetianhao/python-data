intersects(circle, polygon)
intersects(rectangle, polygon)
intersects(shape_a, shape_b)
