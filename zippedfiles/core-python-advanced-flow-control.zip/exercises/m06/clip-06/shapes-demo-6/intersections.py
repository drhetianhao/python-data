def rectangle_intersects_rectangle(ra, rb):
    pass


def rectangle_intersects_circle(r, c):
    pass


def rectangle_intersects_polygon(r, p):
    pass


def circle_intersects_circle(ca, cb):
    pass


def circle_intersects_polygon(c, p):
    pass


def polygon_intersects_polygon(pa, pb):
    pass
