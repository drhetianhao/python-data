while some_condition:
    do_something()
else:
    what()  # ?!
