if some_condition:
    do_something()
else:
    do_this_instead()
