from bisect import bisect_left

s = [5, 8, 19, 34, 35, 53]
