"""Image size functions."""

def image_width(num_pixels=1280):
    return num_pixels
