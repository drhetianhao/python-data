"""Image size functions."""

