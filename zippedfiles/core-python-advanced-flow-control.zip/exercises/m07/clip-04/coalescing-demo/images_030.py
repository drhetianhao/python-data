"""Image size functions."""

def image_width(num_pixels=None):
    return num_pixels or 1280
