integer_divisors or [1]

scale_factor or 1.0

text or "<empty>"
