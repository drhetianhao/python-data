"""Sharing marketing loot."""

def share_stickers(num_stickers, num_developers):
    return num_stickers // num_developers
