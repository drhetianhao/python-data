"""Sharing marketing loot."""

def share_stickers(num_stickers, num_developers):
    return num_developers and num_stickers // num_developers
