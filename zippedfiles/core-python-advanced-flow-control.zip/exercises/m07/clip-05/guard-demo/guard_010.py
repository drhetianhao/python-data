"""Sharing marketing loot."""
