try:
    # This code might raise an exception
    do_something()
    do_something_else()
except ValueError as e:
    # ValueError caught and handled
    handle_value_error(e)
